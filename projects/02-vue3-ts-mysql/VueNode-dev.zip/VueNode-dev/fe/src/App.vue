<template>
  <div class="app-wraper wraper">
    <router-view></router-view>
  </div>
</template>

<script lang="ts" setup>
  
</script>

<style lang="less">
  @import './static/css/tour-app-base.css';
	body {
		background: #fafafa;
	}
</style>
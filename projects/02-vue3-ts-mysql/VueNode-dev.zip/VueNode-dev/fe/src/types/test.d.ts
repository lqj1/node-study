declare module '@/libs/test' {
  export function test():number;
}
